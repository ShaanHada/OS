#!/bin/sh
filename="file.txt"
IFS=","
while read f1 f2 f3;
do
	echo "Name : $f1"
	echo "PRN  : $f2"
	echo "MobileNo: $f3"
done < "$filename"
